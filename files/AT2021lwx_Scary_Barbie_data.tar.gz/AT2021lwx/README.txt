Observations of AT 2021lwx originally published in Bhagya Subrayan et. al 2023, "Scary Barbie: An Extremely Energetic, Long-duration Tidal Disruption Event Candidate without a Detected Host Galaxy at z = 0.995", Astrophysical Journal Letters, 948, L19
doi: 10.3847/2041-8213/accf1a

Photometry file:
AT2021lwx_photometry.txt

Time: Modified Julian Date (MJD)
magpsf: Apparent Magnitude (mag)
sigmapsf: Error in Apparent Magnitude (mag)
fid: Filter identifier
System: Magnitude System (AB)
Facility: ZTF / ATLAS

Spectroscopy files:

Units:

Observed Wavelength (air): Angstroms
Flux: erg/cm2/s/Angs
Flux Error: erg/cm2/s/Angs

UT Date, Filename, Instrument, Telescope

2021 September 10, AT2021lwx_2021September10_LRIS.txt, LRIS, Keck I 10m
2022 May 27, AT2021lwx_2022May27_DBSP.txt, DBSP, Palomar 5.1m 
2022 June 26, AT2021lwx_2022June26_Kast.txt, Kast DS, Lick Shane 3m
2022 September 2, AT2021lwx_2022September2_Kast.txt, Kast DS, Lick Shane 3m
2022 September 25, AT2021lwx_2022September25_LRIS.txt, LRIS, Keck I 10m
2022 October 28, AT2021lwx_2022October28_DBSP.txt, DBSP, Palomar 5.1m 
2022 November 25, AT2021lwx_2022November25_LRIS.txt, LRIS, Keck I 10m